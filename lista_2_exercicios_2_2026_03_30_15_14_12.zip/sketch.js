/*
Soma dos N primeiros números com while Peça ao usuário um número positivo e calcule a soma de todos os números inteiros de 1 até esse número usando um loop while */

let numero = parseInt(prompt("Digite um numero positivo"));
let soma = 0;
let i = 1;

 while (i <= numero) {
  soma += i;
  i++;
}

console.log (`A soma dos numero de 1 até ${numero} é ${soma}`);
