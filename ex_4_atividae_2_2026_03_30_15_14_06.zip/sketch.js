/*Fatorial de um número com while peça ao usuário um número inteiro e calcule o fatorial desse número (ex: 5! = 5 × 4 × 3 × 2 × 1) usando um loop while.*/

let numero = parseInt(prompt("Digite um número inteiro:"));
let fatorial = 1;
let i = numero;
if (numero >= 0) {
  
  while (i > 0) {
    fatorial *= i;
    i--;
  }
  console.log(`O fatorial de ${numero} é: ${fatorial}`);
} else {
  console.log("Por favor, digite um número inteiro não negativo.");
}



