//Elaborar um programa que leia um número. Calcule e informe os seus vizinhos, ou seja, o número anterior e posterior.

let numero = Number(prompt("digite um numero: ")); 
let anterior = numero -1;
let posterior = numero +1;

console.log(`O número digitado foi ${numero} e seu antecessor é ${anterior} e seu sucessor é ${posterior}`)