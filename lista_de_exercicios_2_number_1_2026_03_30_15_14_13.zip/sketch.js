/* Crie um programa que peça um numero ao usuario e mostre a tabuada desse numero de 1 a n */

let numero = Number (prompt("digite um numero para ver a sua tabuada"))

for (let i = 1; i<= 10; i++){
     console.log( `${numero} x ${i} = ${numero * i}`);
}