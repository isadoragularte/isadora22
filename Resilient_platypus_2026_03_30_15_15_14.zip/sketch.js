  let peso,altura,imc;
  Peso = Number(prompt("Digite seu peso em kg:"));
  Altura = Number(prompt("Digite sua altura em metros:"));
  Imc = peso/(altura * altura)
 console.log("o imc é:",imc);


