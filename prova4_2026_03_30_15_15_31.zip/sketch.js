 // Solicita ao usuário que insira duas palavras
  let palavra1 = prompt("Digite a primeira palavra:");
  let palavra2 = prompt("Digite a segunda palavra:");
  
  // Concatena as palavras
  let palavraConcatenada = palavra1 + palavra2;
  
  // Exibe a palavra resultante
  console.log("Resultado: " + palavraConcatenada);
