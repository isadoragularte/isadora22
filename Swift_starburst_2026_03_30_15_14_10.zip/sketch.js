//Números pares entre 1 e 20 com for escreva um programa que mostre todos os números pares entre 1 e 20 utilizando a estrutura for.

for (let i = 1; i <= 20; i++) {
  
  if (i % 2 === 0) {
    console.log(i);
  }
}
