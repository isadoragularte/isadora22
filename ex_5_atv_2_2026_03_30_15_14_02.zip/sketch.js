/*Números ímpares de 1 a N com for peça ao usuário um número N e mostre todos os números ímpares de 1 até N.*/

let N = parseInt(prompt("Digite um número N:"));


for (let i = 1; i <= N; i++) {
  
  if (i % 2 !== 0) {
    console.log(i);
  }
}